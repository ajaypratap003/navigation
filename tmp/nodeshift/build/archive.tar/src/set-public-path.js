import { setPublicPath } from "systemjs-webpack-interop";

setPublicPath("@react-mf/navigation");
